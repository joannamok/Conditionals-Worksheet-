//Mokhtarezadeh_Joanna_4-23-13
//Celsius to Fahrenheight

degrees = 32; //temperature // How many degrees is it outside?
fahrenheight ="f"; // Are you measuring in Fahrenheight ?
celsius = "c"; 	// Are you measuring in Celsius ?
f = (degrees - 32); // equatiion for converting Fahrenheight to Celsius
c = (degrees + 32);	// equation for converting Celsius to Fahrenheight

if(degrees && fahrenheight){
	//Degrees is fahrenheight is chosen
	console.log("The temperature is"+" "+(c)+" "+"degrees Celsius.");
}else{
if(degrees && celsius)
	//Degrees is celsius is chosen
	console.log("The temperature is"+" "+(f)+" "+"degrees Farenheight.");
}

