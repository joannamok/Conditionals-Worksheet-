//Mokhtarezadeh_Joanna_4-23-13
//	Movie Ticket Price

var movieTime = 10;
var age = 12;
var senDiscount = 55;
var kidDiscount = 10;
var timeDiscount = 3 && 4 && 5;
var discountPrice = 7;
var fullPrice = 12;

if(age < kidDiscount || age > 55 || movieTime == timeDiscount){
	console.log(discountPrice);
}else{
	console.log(fullPrice);
}