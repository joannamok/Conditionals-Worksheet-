//Mokhtarezadeh_Joanna_4-23-13
//	Movie Ticket Price

var movieTime = 5; //What time does movie start?
var age = 12; //How old are you?
var senDiscount = 55; // Senior Discount is over 55
var kidDiscount = 10; // Kid Discount is under 10
var timeDiscount = 3 && 4 && 5; // Discounted times of day are 4 tru 5
var discountPrice = 7; // Discounted price 
var fullPrice = 12;  //Full Price

//Price for tickets if discount is included
if(age < kidDiscount || age > 55 || movieTime == timeDiscount){
	console.log("The ticket price is"+" "+(discountPrice));
}else{
	//Price for tickets with no discounts
	console.log("The ticket price is"+" "+(fullPrice));
}