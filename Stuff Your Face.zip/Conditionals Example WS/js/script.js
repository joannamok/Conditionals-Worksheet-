//Mokhtarezadeh_Joanna_4-23-13
//Stuff Your Face

var weight = 145; //competitors weight  // How much does the competitior weigh? 
var min = 135;
//competitor must weigh atleast 135
if(weight<min){
	console.log("You need to gain some weight"); // if less than 135

}else{
	//competitor is over 135
	console.log("You can compete!");
}


