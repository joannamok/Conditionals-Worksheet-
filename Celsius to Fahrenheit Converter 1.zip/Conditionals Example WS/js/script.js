//Mokhtarezadeh_Joanna_4-23-13
//Celsius to Fahrenheight

degrees = 40;
fahrenheight = "f";
celsius = "c";
f = (degrees - 32)/1.8;
c = (degrees + 32)*1.8;

if(degrees && fahrenheight){
	console.log("The temperature is"+" "+(c)+" "+"degrees Celsius.");
}else{(degrees && celsius)
	console.log("The temperature is"+" "+(f)+" "+"degrees Farenheight.");
}


