//Mokhtarezadeh_Joanna_4-23-13
//	Check the Login

username = "joanna";
password = "goat";
correctName = "joanna";
correctWord = "goat";


if(username == correctName && password == correctWord){
	console.log("Welcome"+" "+(username)+"!");
}else{
	console.log("User not found, try again");
}