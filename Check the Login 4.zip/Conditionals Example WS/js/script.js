//Mokhtarezadeh_Joanna_4-23-13
//	Check the Login

username = "joanna"; // What is you username?
password = "car";	// What is you password?
correctName = "joanna"; // correct username
correctWord = "goat";  // correct password

// mesasge if username and password match
if(username == correctName && password == correctWord){
	console.log("Welcome"+" "+(username)+"!");
}else{
	// message if username and password do not match
	console.log("User not found, try again");
}